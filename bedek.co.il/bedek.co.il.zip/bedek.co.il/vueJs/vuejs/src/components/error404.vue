<template>
    <div>
        <h1>הדף לא קיים</h1>
    </div>
</template>

<script>
export default {
    name: "error404",
    beforeCreate(){
        $('.navbar').hide();
    }

}
</script>

<style>

</style>
