<template>
    <div class="container">
        <h1>המתן...</h1>
    </div>
</template>

<script>
export default {
    name:"root"
}
</script>

<style>
   
   
</style>
