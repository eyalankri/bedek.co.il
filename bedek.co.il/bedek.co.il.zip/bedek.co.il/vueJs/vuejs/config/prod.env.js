'use strict'
module.exports = {
  NODE_ENV: '"production"',
  ROOT_API: '"http://api.bedek.co.il/api/"'
}
