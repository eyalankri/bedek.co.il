﻿
namespace api.Enums
{

    public enum UserRoles
    {
        Administrator = 1,
        Handyman = 2,
        Resident = 3,
    }

}
