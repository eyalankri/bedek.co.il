﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace api.Enums
{
    public enum ServiceCallStatus
    {
        New,
        InProgress,
        Completed,
        Deleted
    }
}
